from django.contrib import admin
from web.models import Product, Comment

admin.site.register(Product)
admin.site.register(Comment)